import React from 'react';
import './contentUser3.css';

export default function ContentUser3() {
    return (
        <>
            <div className='cUser'>
                <div className='cUser-Plus'>
                    <button> ver mais </button>
                </div>
            </div>
        </>
    )
}