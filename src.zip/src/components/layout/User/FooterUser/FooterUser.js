import React from 'react';
import './footerUser.css';

export default function FooterUser() {
    return (
        <>
            <div className='fUser'>
                <div className='fUser-Plus'>
                <span> Direitos autorais inclusos no termos. </span>
                <span> Desenvolvido @ 2022 </span>
                </div>
            </div>
        </>
    )
}