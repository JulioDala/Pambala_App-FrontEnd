import React from "react";
import "./shop.css";

import HeaderNavBar from "../HeaderNavBar/HeaderNavBar"
import Loja from "../../../pages/Loja";

export default function Shop(){
    return(
        <div>
<HeaderNavBar/>
<Loja/>
        </div>
    )
}