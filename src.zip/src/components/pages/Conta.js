import React from 'react'
import './conta.css'
import SideBarUser from './SidebarUser/SideBarUser'


export default function Conta() {
    return (
        <div classname="container-conta">
           
           <SideBarUser />
           
        </div>
    )
}